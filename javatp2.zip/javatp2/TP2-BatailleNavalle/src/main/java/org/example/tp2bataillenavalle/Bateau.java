package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe Bateau représente un bateau dans le jeu de la bataille navale.
 * On y retrouve des informations sur la taille, l'orientation, la position et l'état du bateau.
 */
public abstract class Bateau {
    private Image image;
    private int positionX;
    private int positionY;
    private boolean orientation;
    private int taille;
    private boolean estPlace;

    /**
     * Constructeur de la classe Bateau.
     * Initialise l'image du bateau.
     *
     * @param image l'image du bateau
     */
    public Bateau(Image image){
        this.image = image;
        this.estPlace = false;
    }

    public Image getImage(){
        return image;
    }

    public void setPosition(int positionX, int positionY){
        this.positionX = positionX;
        this.positionY = positionY;
    }

    public int getPositionX(){
        return positionX;
    }

    public int getPositionY(){
        return positionY;
    }

    /**
     * Retourne l'orientation du bateau.
     *
     * @return l'orientation du bateau
     */
    public boolean isOrientation(){
        return orientation;
    }

    public void setOrientation(boolean orientation){
        this.orientation = orientation;
    }

    /**
     * Retourne la taille du bateau.
     *
     * @return la taille du bateau
     */
    public int getSize(){
        return taille;
    }

    public void setSize(int taille){
        this.taille = taille;
    }

    public boolean isPlaced() {
        return estPlace;
    }

    public void setPlaced(boolean placed) {
        this.estPlace = placed;
    }

    public abstract int getType();
}