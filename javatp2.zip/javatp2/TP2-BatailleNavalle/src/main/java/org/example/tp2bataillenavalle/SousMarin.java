package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe SousMarin représente un sous-marin dans le jeu de la bataille navale.
 * Elle hérite de la classe Bateau et a une taille attitrée de 3.
 */

public class SousMarin extends Bateau {

    /**
     * Constructeur de la classe SousMarin.
     * Initialise la taille du sous-marin et l'image associée.
     *
     * @param image l'image du sous-marin
     */
    public SousMarin(Image image) {
        super(image);
        super.setSize(3);
    }

    @Override
    public int getType() {
        return 4;
    }
}