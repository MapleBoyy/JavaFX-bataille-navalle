package org.example.tp2bataillenavalle;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
/**
 * @author Gabriel Faucon
 * @version 1.0
 * @date 21/04/2024
 * Classe de base du projet.
 * Elle charge la première scene et s'occupe de charger les autres scenes.
 */
public class HelloApplication extends Application {

    static Stage stage;
    static Scene scene;
    /**
     * Methode appelee au lancement de l'application.
     * Elle va afficher la première scene qui est menu.fxml
     *
     * @param stage le stage principal de l'application
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("menu.fxml"));
        HelloApplication.stage = stage;
        scene = new Scene(fxmlLoader.load());
        stage.minHeightProperty().setValue(600);
        stage.maxHeightProperty().setValue(700);
        stage.minWidthProperty().setValue(800);
        stage.maxWidthProperty().setValue(1200);
        stage.setTitle("Menu du tictactoe");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Méthode pour changer de scene.
     * Elle va charger le placement des bateaux par le joueur
     *
     * @param sceneacharger le nom du fichier FXML à charger
     * @throws IOException si le fichier FXML ne peut pas être chargé
     */
    public static void changerScene(String sceneacharger) throws IOException{
        FXMLLoader fxmlloader = new FXMLLoader(HelloApplication.class.getResource(sceneacharger + ".fxml"));
        scene = new Scene(fxmlloader.load(), 800, 600);
        stage.setResizable(false);
        stage.setTitle("TIC-TAC-TOE");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}