package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe ContreTorpilleur représente un contre-torpilleur dans le jeu de la bataille navale.
 * Elle hérite de la classe Bateau et a une taille attitrée de 3.
 */

public class ContreTorpilleur extends Bateau {

    /**
     * Constructeur de la classe ContreTorpilleur.
     * Initialise la taille du contre-torpilleur et l'image associée.
     *
     * @param image l'image du contre-torpilleur
     */
    public ContreTorpilleur(Image image) {
        super(image);
        super.setSize(3);
    }

    @Override
    public int getType() {
        return 3;
    }
}