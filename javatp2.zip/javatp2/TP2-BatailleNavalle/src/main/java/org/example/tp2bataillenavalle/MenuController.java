package org.example.tp2bataillenavalle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class MenuController {
    @FXML
    private void afficherApplication(ActionEvent event) throws IOException{
        HelloApplication.changerScene("choixPlacements");
    }

    @FXML
    public void quitterApplication(ActionEvent event){
        Platform.exit();
    }
}
