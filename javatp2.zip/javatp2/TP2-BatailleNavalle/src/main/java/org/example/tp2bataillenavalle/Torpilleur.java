package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe Torpilleur représente un torpilleur dans le jeu de la bataille navale.
 * Elle hérite de la classe Bateau et a une taille attitrée de 2.
 */
public class Torpilleur extends Bateau {

    /**
     * Constructeur de la classe Torpilleur.
     * Initialise la taille du torpilleur et l'image associée.
     *
     * @param image l'image du torpilleur
     */
    public Torpilleur(Image image) {
        super(image);
        super.setSize(2);
    }

    @Override
    public int getType() {
        return 5;
    }
}