package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe PorteAvion représente un porte-avions dans le jeu de la bataille navale.
 * Elle hérite de la classe Bateau et a une taille attitrée de 5.
 */
public class PorteAvion extends Bateau {

    /**
     * Constructeur de la classe PorteAvion.
     * Initialise la taille du porte-avions et l'image associée.
     *
     * @param image l'image du porte-avions
     */
    public PorteAvion(Image image) {
        super(image);
        super.setSize(5);
    }

    @Override
    public int getType() {
        return 1;
    }
}