package org.example.tp2bataillenavalle;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

/**
 * S'occupe du placement des bateaux sur la grille.
 * Elle gère l'interaction de l'utilisateur avec l'interface pour placer les bateaux et elle va mettre à jour la grille en conséquence.
 */
public class PlacementBateau {
    @FXML
    private Button btnContreTorpilleur;
    @FXML
    private Button btnCroiseur;
    @FXML
    private Button btnPorteAvion;
    @FXML
    private Button btnSousMarin;
    @FXML
    private Button btnTorpilleur;
    @FXML
    private CheckBox directionBateau;
    @FXML
    private GridPane gridPane;
    @FXML
    private ImageView ImageViewBateau;

    private ContreTorpilleur contreTorpilleur;
    private Croiseur croiseur;
    private PorteAvion porteAvions;
    private SousMarin sousMarin;
    private Torpilleur torpilleur;

    private List<Bateau> bateaux = new ArrayList<>();
    private Bateau bateauSelectionne;
    private int[][] grille = new int[10][10];


    /**
     * Cette méthode lie la taille de l'ImageView à la taille de la GridPane.
     */
    @FXML
    public void initialize(){

        //Initialisation de la grille
        contreTorpilleur = new ContreTorpilleur(new Image(getClass().getResourceAsStream("/Images/contre-torpilleur.png")));
        croiseur = new Croiseur(new Image(getClass().getResourceAsStream("/Images/croiseur.png")));
        porteAvions = new PorteAvion(new Image(getClass().getResourceAsStream("/Images/porte-avion.png")));
        sousMarin = new SousMarin(new Image(getClass().getResourceAsStream("/Images/sous-marin.png")));
        torpilleur = new Torpilleur(new Image(getClass().getResourceAsStream("/Images/torpilleur.png")));
        bateaux.add(contreTorpilleur);
        bateaux.add(croiseur);
        bateaux.add(porteAvions);
        bateaux.add(sousMarin);
        bateaux.add(torpilleur);



        char[] letters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};

        for (int i = 0; i < letters.length; i++) {
            Label label = new Label(String.valueOf(letters[i]));
            label.setAlignment(Pos.CENTER);
            gridPane.add(label, i+1, 0);
        }

        for (int i = 1; i <= 10; i++) {
            Label label = new Label(String.valueOf(i));
            gridPane.add(label, 0, i);
        }

        for (int i = 0; i < 10; i++){
            for (int j = 0; j<10; j++){
                Pane pane = new Pane();
                pane.setPrefSize(40, 40);
                pane.getStyleClass().add("cell");
                pane.setOnMouseClicked(this::placerBateau);
                gridPane.add(pane, i+1, j+1);
            }
        }

    }

    @FXML
    public void selectionnerContreTorpilleur(){
        selectionnerBateau(contreTorpilleur);
    }

    @FXML
    public void selectionnerCroiseur(){
        selectionnerBateau(croiseur);
    }

    @FXML
    public void selectionnerPorteAvions(){
        selectionnerBateau(porteAvions);
    }

    @FXML
    public void selectionnerSousMarin(){
        selectionnerBateau(sousMarin);
    }

    @FXML
    public void selectionnerTorpilleur(){
        selectionnerBateau(torpilleur);
    }

    /**
     * S'active lorsque l'utilisateur sélectionne un bateau à placer sur la grille.
     * Elle met à jour le bateau sélectionné et met à jour l'ImageView pour afficher l'image du bateau sélectionné.
     *
     * @param bateau le bateau que l'utilisateur a sélectionné pour le placement
     */
    public void selectionnerBateau(Bateau bateau){
        bateauSelectionne = bateau;
        if(bateauSelectionne != null){
            ImageView imageView = new ImageView(bateauSelectionne.getImage());
            imageView.setFitWidth(30);
            imageView.setFitHeight(30);
            bateauSelectionne.setOrientation(directionBateau.isSelected());
            ImageViewBateau.setImage(bateauSelectionne.getImage());
        }
    }

    /**
     * Cette méthode est appelée lorsque l'utilisateur clique sur une cellule de la GridPane pour placer un bateau.
     * Elle vérifie si un bateau a été sélectionné et si ce bateau n'a pas déjà été placé.
     * Elle vérifie si le bateau peut être placé à la position voulue par l'utilisateur en fonction de sa taille et de son orientation.
     * Si le bateau peut être placé, elle met à jour la grille et l'interface utilisateur pour afficher le bateau à la nouvelle position.
     *
     * @param event l'événement de clic de souris qui a déclenché cette méthode
     */
    @FXML
    public void placerBateau(MouseEvent event){
        if(bateauSelectionne != null && !bateauSelectionne.isPlaced()){
            Pane clickedPane = (Pane) event.getSource();
            int positionX = GridPane.getColumnIndex(clickedPane);
            int positionY = GridPane.getRowIndex(clickedPane);

            //Vérification si le bateau peut être placé à la position voulue
            if(bateauSelectionne.isOrientation() && positionX + bateauSelectionne.getSize() >= 10){
                System.out.println("pas assez de place pour placer le bateau horizontalement");
                return;
            } else if(!bateauSelectionne.isOrientation() && positionY + bateauSelectionne.getSize() >= 10){
                System.out.println("pas assez de place pour placer le bateau verticalement");
                return;
            }

            //Vérification si la cellule est déjà occupée
            for(int i = 0; i < bateauSelectionne.getSize(); i++){
                if(bateauSelectionne.isOrientation()){
                    if(grille[positionX + i][positionY] != 0){
                        System.out.println("cette cellule est deja occupee");
                        return;
                    }
                } else {
                    if(grille[positionX][positionY + i] != 0){
                        System.out.println("cette cellule est deja occupee");
                        return;
                    }
                }
            }

            bateauSelectionne.setPosition(positionX, positionY);

            //Affichage du fond dans la grille
            ImageView imageView = new ImageView(bateauSelectionne.getImage());
            imageView.setPreserveRatio(true);
            imageView.setFitWidth(clickedPane.getPrefWidth() * bateauSelectionne.getSize());
            imageView.setFitHeight(clickedPane.getPrefHeight());

            //Check si le bateau est horizontal ou vertical
            if(bateauSelectionne.isOrientation()){
                gridPane.add(imageView, positionX, positionY);
                GridPane.setColumnSpan(imageView, bateauSelectionne.getSize());
            } else {
                imageView.setRotate(90);
                gridPane.add(imageView, positionX, positionY);
                GridPane.setRowSpan(imageView, bateauSelectionne.getSize());
            }

            //Mise à jour de la grille
            int bateauType = bateauSelectionne.getType();
            for(int i = 0; i < bateauSelectionne.getSize(); i++){
                if(bateauSelectionne.isOrientation()){
                    grille[positionX + i][positionY] = bateauType;
                } else {
                    grille[positionX][positionY + i] = bateauType;
                }
            }

            bateauSelectionne.setPlaced(true);
            bateauSelectionne = null;
        } else {
            System.out.println("Ce bateau a deja été placé ou aucun bateau n'a été sélectionné");
        }
    }


}