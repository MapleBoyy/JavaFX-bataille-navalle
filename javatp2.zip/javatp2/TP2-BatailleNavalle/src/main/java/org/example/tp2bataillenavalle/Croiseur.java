package org.example.tp2bataillenavalle;

import javafx.scene.image.Image;

/**
 * La classe Croiseur représente un croiseur dans le jeu de la bataille navale.
 * Elle hérite de la classe Bateau et a une taille attitrée de 4.
 */

public class Croiseur extends Bateau {

    /**
     * Constructeur de la classe Croiseur.
     * Initialise la taille du croiseur et l'image associée.
     *
     * @param image l'image du croiseur
     */
    public Croiseur(Image image) {
        super(image);
        super.setSize(4);
    }

    @Override
    public int getType() {
        return 2;
    }
}