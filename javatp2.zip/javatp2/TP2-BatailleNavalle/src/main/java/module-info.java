module org.example.tp2bataillenavalle {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.tp2bataillenavalle to javafx.fxml;
    exports org.example.tp2bataillenavalle;
}